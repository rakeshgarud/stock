export class Filters {
  name: string;
  key: string;
  direction: any;
}