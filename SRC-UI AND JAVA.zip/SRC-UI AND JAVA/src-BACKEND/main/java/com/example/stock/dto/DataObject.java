package com.example.stock.dto;

import java.util.List;

public class DataObject {

	private List<Filter> filter;

	public List<Filter> getFilter() {
		return filter;
	}

	public void setFilter(List<Filter> filter) {
		this.filter = filter;
	}
	
	
 }
