export class Stock {
  id: number;
  name: string;
  closePrice: number;
  ttlTradeQty: number;
}
