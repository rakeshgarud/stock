package com.example.stock.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.example.stock.bean.EquityDerivative;
import com.example.stock.constants.Constant;
import com.example.stock.repo.EquityDerivativeRepository;
import com.example.stock.scheduler.Scheduler;
import com.example.stock.util.DateUtil;
import com.example.stock.util.EquityDerivativesUtil;
import com.example.stock.util.FileUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class EquityLookupService {
	
	@Autowired
	private EquityDerivativeRepository equityRepository;
	
	@Autowired
	private ConfigService configService;
	
	private final static Logger logger = LoggerFactory.getLogger(EquityLookupService.class);
	
	@Async("threadPoolTaskExecutor")
    public void loadEquityData() throws InterruptedException {
		
       List<HashMap<String, Object>> symbols = configService.getFileAsList("stock-list.json");
       	for(HashMap<String, Object> symbol : symbols) {
       		String url = Constant.EQUITY_CHART_URL.split("=")[0]+"="+symbol.get("symbol");
    		List<Map<String, Double>> resultObj = EquityDerivativesUtil.getEquityData(url);
    		logger.info("Fetching data for : "+symbol.get("symbol")+" URL ="+url);
    		List<EquityDerivative> equities = new ArrayList<EquityDerivative>();

    		resultObj.forEach(s -> {
    			ObjectMapper mapper = new ObjectMapper();
    			EquityDerivative equity = new EquityDerivative();
    			equity = mapper.convertValue(s, EquityDerivative.class);
    			equity.setSymbol(symbol.get("symbol").toString());
    			equity.setDate(DateUtil.getCurretDate());
    			equity.setId(null);
    			equities.add(equity);
    		});
    		String sourceDir = (String) configService.getConfigByName(Constant.STOCK_OPTIONS_SOURCE_DIR);
    		FileUtil.saveAsJsonObjectFile(equities,sourceDir);
    		equityRepository.saveAll(equities);
    		logger.info("Record successfully saved for : "+symbol.get("symbol")+" URL ="+url);
       	}
    }
	
}
