package com.example.stock.service;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.stock.bean.EquityDerivative;
import com.example.stock.bean.EquityDerivativePredicate;
import com.example.stock.bean.ExchangeActivity;
import com.example.stock.bean.Stock;
import com.example.stock.bean.StockPredicate;
import com.example.stock.constants.Constant;
import com.example.stock.dto.Filter;
import com.example.stock.dto.SearchFilter;
import com.example.stock.enums.Column;
import com.example.stock.enums.Direction;
import com.example.stock.repo.EquityDerivativeRepository;
import com.example.stock.repo.ExchangeActivityRepository;
import com.example.stock.repo.StockRepository;
import com.example.stock.util.CSVReader;
import com.example.stock.util.DateUtil;
import com.example.stock.util.EquityDerivativesUtil;
import com.example.stock.util.FileUtil;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class StockServiceImpl implements StockService {

	private String DIR = "D:\\Equity Data";

	@Autowired
	private StockRepository stockRepository;
	
	@Autowired
	private ConfigService configService;
	
	private final static Logger logger = LoggerFactory.getLogger(EquityLookupService.class);

	@Autowired
	private EquityDerivativeRepository equityDerivativeRepository;
	
	@Autowired
	private ExchangeActivityRepository activityRepository;

	private List<Stock> thisDateStock = Arrays.asList();

	@Override
	public List<Stock> getAllStocks() {
		return (List<Stock>) stockRepository.findAll();
	}

	@Override
	public void saveStocks(String sourceDir) {
		sourceDir =  (String) configService.getConfigByName(Constant.STOCK_SOURCE_DIR);
		loadStockFromFile(sourceDir, ".csv");
	}

	@Override
	public List<Stock> getStocks(Date startDate, Date endDate) {
		return stockRepository.getAllStocksBetweenDates(startDate, endDate);
	}

	@Override
	public List<Stock> findHoldingStocks(Date startDate, Date endDate, List<Filter> filters) {
		List<Stock> finalStock = new ArrayList<Stock>();

		List<Date> dates = stockRepository.getDistinctDateBetweenRange(startDate, endDate);
		startDate = dates.get(0);
		endDate = dates.get(dates.size() - 1);
		thisDateStock = stockRepository.getAllStocksBetweenDates(startDate, startDate);

		for (Date date : dates) {
			
			finalStock = getGreateStock(thisDateStock, date, filters);
			if (finalStock.size() > 0 && thisDateStock.size() == 0) {
				break;
			}
			startDate = new Date(startDate.getTime() + (1000 * 60 * 60 * 24));
		}
		return finalStock;
	}

	private List<Stock> getGreateStock(List<Stock> startStock, Date date, List<Filter> filters) {
		List<Stock> finalStock = new ArrayList<Stock>();

		List<Stock> stockNext = stockRepository.getAllStocksBetweenDates(date, date);

		startStock.forEach(start -> {
			Optional<Stock> stock = stockNext.stream().filter(s -> s.getName().equalsIgnoreCase(start.getName()))
					.findFirst();

			if (stock.isPresent()) {
				/*
				 * if(stock.get().getClosePrice()>start.getClosePrice()) {
				 * finalStock.add(stock.get()); }
				 */
				Boolean isMatch = false;
				for (Filter filt : filters) {
					switch (filt.getKey()) {

					case "CLOSE_PRICE":
						if (Direction.UP.name().equalsIgnoreCase(filt.getDirection()))
							isMatch = StockPredicate.filterAndGet(stock.get(),
									StockPredicate.isClosePriceGreater(start.getClosePrice()));
						else
							isMatch = StockPredicate.filterAndGet(stock.get(),
									StockPredicate.isClosePriceLess(start.getClosePrice()));
						break;
					case "TRADE_QTY":
						if (Direction.UP.name().equalsIgnoreCase(filt.getDirection()))
							isMatch = StockPredicate.filterAndGet(stock.get(),
									StockPredicate.isTtlTradeQtyGreater(start.getTtlTradeQty()));
						else
							isMatch = StockPredicate.filterAndGet(stock.get(),
									StockPredicate.isTtlTradeQtyLess(start.getTtlTradeQty()));
						break;
					case "DELIV_QTY":
						if (Direction.UP.name().equalsIgnoreCase(filt.getDirection()))
							isMatch = StockPredicate.filterAndGet(stock.get(),
									StockPredicate.isDeliverQtyGreater(start.getClosePrice()));
						else
							isMatch = StockPredicate.filterAndGet(stock.get(),
									StockPredicate.isDeliverQtyLess(start.getTtlTradeQty()));
						break;
					case "DELIV_PER":
						if (Direction.UP.name().equalsIgnoreCase(filt.getDirection()))
							isMatch = StockPredicate.filterAndGet(stock.get(),
									StockPredicate.isDeliverPerGreater(start.getTtlTradeQty()));
						else
							isMatch = StockPredicate.filterAndGet(stock.get(),
									StockPredicate.isDeliverPerLess(start.getTtlTradeQty()));
						break;
					default:
						break;
					}
					if (isMatch)
						continue;
					else
						break;
				}
				if (isMatch || filters.isEmpty()) {
					finalStock.add(stock.get());
				}
				// boolean st = StockPredicate.filterAndGet(stock.get(),
				// StockPredicate.isClosePriceGreater(start.getClosePrice()));

			}

		});
		thisDateStock = stockNext;
		return finalStock;

	}

	List<Stock> process(List<Stock> stocks, Predicate<Stock> predicate) {
		List<Stock> result = new ArrayList<>();
		for (Stock stock : stocks) {
			if (predicate.test(stock)) {
				result.add(stock);
			}
		}
		return result;
	}

	private void loadStockFromFile(String sourceDir, String fileFormat) {
		if (sourceDir != null) {
			DIR = sourceDir;
		}else
			DIR =  (String) configService.getConfigByName(Constant.STOCK_SOURCE_DIR);
		File[] files = FileUtil.getAllFiles(DIR, fileFormat);
		for (int i = 0; i < files.length; i++) {
			List<Stock> stocks = CSVReader.writeCsvToStock(files[i].getAbsolutePath());
			stockRepository.saveAll(stocks);
		}
	}

	@Override
	public List<EquityDerivative> serachEquity(SearchFilter search) {

		Date startDate = DateUtil.addDaysToDate(-1);
		Date endDate = DateUtil.getCurretDate();
		if (search.getStartDate() != null && search.getEndDate() != null) {
			startDate = DateUtil.getDateWithoutTime(search.getStartDate());
			endDate = DateUtil.getDateWithoutTime(search.getEndDate());
		}
		// List<EquityDerivative> equities =
		// equityDerivativeRepository.getAllEquitiesBetweenDatesAndByType(startDate,
		// endDate,Column.valueOf(colType).ordinal());
		List<Date> dates = equityDerivativeRepository.getDistinctDateBetweenRange(startDate, endDate);
		List<EquityDerivative> finalEquity = new ArrayList<EquityDerivative>();
		for (Date date : dates) {
			finalEquity.addAll(getEquitiesByDates(date, date, search));
		}
		return finalEquity;
	}

	private List<EquityDerivative> getEquitiesByDates(Date startDate, Date endDate, SearchFilter search) {
		List<Filter> filters = search.getFilter();

		List<EquityDerivative> finalEquity = new ArrayList<EquityDerivative>();
		if (search.getStrikePrice() > 0) {
			List<EquityDerivative> equities = equityDerivativeRepository.getEquitiesByStrikePriceBetweenDatesAndByType(
					startDate, endDate, search.getStrikePrice(), Column.valueOf(search.getType()).ordinal());
			return equities;
		}
		if(search.getSymbol() == null) {
			search.setSymbol("");
		}
		List<EquityDerivative> equities = equityDerivativeRepository.getAllEquitiesBetweenDatesAndByType(startDate,
				endDate, Column.valueOf(search.getType()).ordinal(),search.getSymbol());

		for (Filter filt : filters) {
			switch (filt.getKey()) {
			case "OI":
				finalEquity.addAll(equities.stream().sorted(Comparator.comparing(EquityDerivative::getOi).reversed())
						.limit(search.getRecordCount()).collect(Collectors.toList()));
				break;
			case "CHANGE_IN_OI":
				List<EquityDerivative> chngEquities = getChninOISort(equities);
				List<EquityDerivative> sortedList = chngEquities.stream()
						.sorted(Comparator.comparing(EquityDerivative::getChnginOI).reversed()).limit(search.getRecordCount())
						.collect(Collectors.toList());
				finalEquity.addAll(equities.stream()
						.filter(line -> sortedList.stream().anyMatch(s -> s.getRowNo() == line.getRowNo()))
						.collect(Collectors.toList()));
				break;
			case "STRIKE_PRICE":
				finalEquity.addAll(equities.stream().filter(line -> line.getStrikePrice() == filt.getValue())
						.collect(Collectors.toList()));
				break;
			}

		}
		if (filters.isEmpty()) {
			finalEquity = equities.stream().limit(search.getRecordCount()).collect(Collectors.toList());
		}

		return finalEquity.stream()
				.filter(EquityDerivativePredicate.distinctByKeys(EquityDerivative::getRowNo, EquityDerivative::getDate))
				.collect(Collectors.toList());
	}

	@Override
	public void saveEquityDerivatives(String url) {
		List<Map<String, Double>> resultObj = EquityDerivativesUtil.getEquityData(Constant.EQUITY_CHART_URL);
		List<EquityDerivative> equities = new ArrayList<EquityDerivative>();
		resultObj.forEach(s -> {
			ObjectMapper mapper = new ObjectMapper();
			EquityDerivative equity = new EquityDerivative();
			equity = mapper.convertValue(s, EquityDerivative.class);
			equity.setDate(DateUtil.getCurretDate());
			equity.setId(null);
			equities.add(equity);
		});
		String sourceDir = (String) configService.getConfigByName(Constant.NIFTY_SOURCE_DIR);
		FileUtil.saveAsJsonObjectFile(equities,sourceDir);
		
		//equities.addAll(loadEquityFromFile(sourceDir, ".json"));
		equityDerivativeRepository.saveAll(equities);
	}

	private List<EquityDerivative> loadEquityFromFile(String sourceDir, String fileFormat) {
		if (sourceDir != null) {
			DIR = sourceDir;
		}
		List<EquityDerivative> equities = new ArrayList<EquityDerivative>();
		File[] files = FileUtil.getAllFiles(DIR, fileFormat);
		if (files == null) {
			return Arrays.asList();
		}
		for (int i = 0; i < files.length; i++) {
			ObjectMapper mapper = new ObjectMapper();
			mapper.setSerializationInclusion(Include.NON_NULL);
			try {
				equities.addAll(Arrays.asList(mapper.readValue(files[i], EquityDerivative[].class)));
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		return equities;
	}

	// For sorting to skip negative value.
	// If negative value's no of digits is greater, then the value should be consider
	// in sorting.
	private List<EquityDerivative> getChninOISort(List<EquityDerivative> equities) {

		List<EquityDerivative> list = new ArrayList<EquityDerivative>();
		equities.forEach(s -> {
			EquityDerivative e = s;
			Double d = s.getChnginOI();
			if (s.getChnginOI() < 0) {
				d = s.getChnginOI() * -1;
			}
			e.setChnginOI(d);
			list.add(e);
		});

		return list;
	}

	@Override
	public List<EquityDerivative> getPremiumDK(SearchFilter search) {
		Date startDate = DateUtil.addDaysToDate(-search.getDays());
		Date endDate = DateUtil.getCurretDate();
		if (search.getStartDate() != null ) {
			startDate = DateUtil.getDateWithoutTime(search.getStartDate());
			if(search.getEndDate() != null)
				endDate = DateUtil.getDateWithoutTime(search.getEndDate());
			else
				endDate = DateUtil.getCurretDate();
		}

		try {
			List<Date> dates = equityDerivativeRepository.getDistinctDateBetweenRange(startDate, endDate);
			List<EquityDerivative> searchedEquity = new ArrayList<EquityDerivative>();
			for (Date date : dates) {
				Date thisDate = date;
				Date prevDate = DateUtil.addDaysToDate(date, -1);
				List<EquityDerivative> thisEqty = getEquitiesByDates(thisDate, thisDate, search);
				List<EquityDerivative> prevEqty = getEquitiesByDates(prevDate,prevDate, search);
				thisEqty.stream().forEach(thseq -> {
					
					Optional<EquityDerivative> eqty= prevEqty.stream().filter(pre->pre.getStrikePrice() == thseq.getStrikePrice()).findFirst();
					if(eqty.isPresent()) {
						EquityDerivative diffEqty = eqty.get();
						diffEqty.setOi(thseq.getOi()-eqty.get().getOi());
						diffEqty.setChnginOI(thseq.getChnginOI()-eqty.get().getChnginOI());
						diffEqty.setIv(thseq.getIv()-eqty.get().getIv());
						diffEqty.setLtp(thseq.getLtp()-eqty.get().getLtp());
						thseq.setPrevEquity(diffEqty);
					}
				});
				
				searchedEquity.addAll(thisEqty);
			}
			return searchedEquity;
		} catch (Exception e) {
			System.out.println(e);
		}
		return null;
	}


	@Override
	public void loadEquityFromCloud() {
		
		String url = Constant.EQUITY_CHART_URL;
		List<Map<String, Double>> resultObj = EquityDerivativesUtil.getEquityData(url);
		List<EquityDerivative> equities = new ArrayList<EquityDerivative>();

		resultObj.forEach(s -> {
			ObjectMapper mapper = new ObjectMapper();
			EquityDerivative equity = new EquityDerivative();
			equity = mapper.convertValue(s, EquityDerivative.class);
			equity.setDate(DateUtil.getCurretDate());
			equity.setId(null);
			equities.add(equity);
		});
		String sourceDir = (String) configService.getConfigByName(Constant.NIFTY_SOURCE_DIR);
		FileUtil.saveAsJsonObjectFile(equities,sourceDir);
		equityDerivativeRepository.saveAll(equities);
	}

	@Override
	public void loadActivityData() throws Exception {
		String dir = (String) configService.getConfigByName(Constant.FII_SOURCE_DIR);
		File[] files = FileUtil.getAllFiles(dir, ".csv");
		for (int i = 0; i < files.length; i++) {
			List<ExchangeActivity> exchangeActivity = CSVReader.writeCsvToActivity(files[i].getAbsolutePath());
			activityRepository.saveAll(exchangeActivity);
		}
		}
	
	
	@Override
	public List<ExchangeActivity> getActivityData(Date startDate,Date endDate) throws Exception {
		return (List<ExchangeActivity>) activityRepository.findAll();
	}

	//Load equity data from file to DB
	@Override
	public void loadEquityToDB() {
		List<EquityDerivative> equities = new ArrayList<EquityDerivative>();
		String sourceDir = (String) configService.getConfigByName(Constant.STOCK_SOURCE_DIR);
		equities = loadEquityFromFile(sourceDir, ".json");
		equityDerivativeRepository.saveAll(equities);
		sourceDir = (String) configService.getConfigByName(Constant.STOCK_OPTIONS_SOURCE_DIR);
		equities = loadEquityFromFile(sourceDir, ".json");
		equityDerivativeRepository.saveAll(equities);
	}

	//Load stocks data from file to DB
	@Override
	public void loadStockDataToDB() {
		String sourceDir =  (String) configService.getConfigByName(Constant.STOCK_SOURCE_DIR);
		loadStockFromFile(sourceDir, ".csv");
	}

	@Override
	public void loadStockOptionsData() {

	       List<HashMap<String, Object>> symbols = configService.getFileAsList("stock-list.json");
	       	for(HashMap<String, Object> symbol : symbols) {
	       		String url = Constant.EQUITY_CHART_URL.split("=")[0]+"="+symbol.get("symbol");
	    		List<Map<String, Double>> resultObj = EquityDerivativesUtil.getEquityData(url);
	    		logger.info("Fetching data for : "+symbol.get("symbol")+" URL ="+url);
	    		List<EquityDerivative> equities = new ArrayList<EquityDerivative>();

	    		resultObj.forEach(s -> {
	    			ObjectMapper mapper = new ObjectMapper();
	    			EquityDerivative equity = new EquityDerivative();
	    			equity = mapper.convertValue(s, EquityDerivative.class);
	    			equity.setSymbol(symbol.get("symbol").toString());
	    			equity.setDate(DateUtil.getCurretDate());
	    			equity.setId(null);
	    			equities.add(equity);
	    		});
	    		String sourceDir = (String) configService.getConfigByName(Constant.STOCK_OPTIONS_SOURCE_DIR);
	    		FileUtil.saveAsJsonObjectFile(equities,sourceDir);
	    		equityDerivativeRepository.saveAll(equities);
	    		logger.info("Record successfully saved for : "+symbol.get("symbol")+" URL ="+url);
	       	}
	    

		// TODO Auto-generated method stub
		
	}
}
