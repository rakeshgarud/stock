package com.example.stock.bean;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
public class EquityDerivative {

	@Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;
	@Column
	private String symbol;
	@Column
	private double oi;
	@Column
	private double chnginOI;
	@Column
	private double volume;
	@Column
	private double iv;
	@Column
	private double ltp;
	@Column
	private double netChng;
	@Column
	private double bidQty;
	@Column
	private double bidPrice;
	@Column
	private double askPrice;
	@Column
	private double askQty;
	@Column
	private double strikePrice;
	@Column
	private Date date;
	@Column
	private int type;
	@Column
	private int rowNo;
	
	@Transient
	private EquityDerivative prevEquity;
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public double getOi() {
		return oi;
	}
	public void setOi(double oi) {
		this.oi = oi;
	}
	public double getChnginOI() {
		return chnginOI;
	}
	public void setChnginOI(double changeInOI) {
		this.chnginOI = changeInOI;
	}
	public double getVolume() {
		return volume;
	}
	public void setVolume(double volume) {
		this.volume = volume;
	}
	public double getIv() {
		return iv;
	}
	public void setIv(double iv) {
		this.iv = iv;
	}
	public double getLtp() {
		return ltp;
	}
	public void setLtp(double ltp) {
		this.ltp = ltp;
	}
	public double getNetChng() {
		return netChng;
	}
	public void setNetChng(double netChng) {
		this.netChng = netChng;
	}
	public double getBidQty() {
		return bidQty;
	}
	public void setBidQty(double bidQty) {
		this.bidQty = bidQty;
	}
	public double getBidPrice() {
		return bidPrice;
	}
	public void setBidPrice(double bidPrice) {
		this.bidPrice = bidPrice;
	}
	public double getAskPrice() {
		return askPrice;
	}
	public void setAskPrice(double askPrice) {
		this.askPrice = askPrice;
	}
	public double getAskQty() {
		return askQty;
	}
	public void setAskQty(double askQty) {
		this.askQty = askQty;
	}
	public double getStrikePrice() {
		return strikePrice;
	}
	public void setStrikePrice(double strikePrice) {
		this.strikePrice = strikePrice;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public int getRowNo() {
		return rowNo;
	}
	public void setRowNo(int row) {
		this.rowNo = row;
	}
	public EquityDerivative getPrevEquity() {
		return prevEquity;
	}
	public void setPrevEquity(EquityDerivative prevEquity) {
		this.prevEquity = prevEquity;
	}
	@Override
	public String toString() {
		return "EquityDerivative [oi=" + oi + ", changeInOI=" + chnginOI + ", volume=" + volume + ", iv=" + iv
				+ ", ltp=" + ltp + ", netChng=" + netChng + ", bidQty=" + bidQty + ", bidPrice=" + bidPrice
				+ ", askPrice=" + askPrice + ", askQty=" + askQty + ", strikePrice=" + strikePrice + ", date=" + date
				+ ", type=" + type + ", rowNo=" + rowNo + "]";
	}
	
}
